#!bin/bash
export FLASK_APP='/var/www/ACATblog/manage.py'
export FLASK_CONFIG='aliyun'
export ADMIN_USERNAME='admin'
export ADMIN_PASSWORD='busy'
